package zooapp;
import Animals.*;
import Staff.*;
import java.util.ArrayList;

public class ZooApp {
    
    public static void main(String[] args) {  
        
        // List of duties - Veterinarian
        ArrayList <String> dutiesVet = new ArrayList<>();
        dutiesVet.add("Reports health conditions and treatments");
        dutiesVet.add("Keeps vaccinations up to date");
        dutiesVet.add("Treats sick animals");
        dutiesVet.add("Pet the animals :) ");
        
        
        // List of duties - ZooKeeper
        ArrayList <String> dutiesZk = new ArrayList<>();
        dutiesZk.add("Feeding animals");
        dutiesZk.add("Cleaning the enclosure");
        dutiesZk.add("Training animals");
        
        //List of duties - Vendedor de voletas 
        ArrayList <String> duetiesVed = new ArrayList <>();
        dutiesVed.add("LLevar las cuentas ");
        dutiesVed.add("Indicar a los visitantes por donde ir");
        dutiesVed.add("Atender a las personas"); 
        
        
        /*
        //Veterinarians
        Veterinarian vet1 = new Veterinarian("Mark", 35, dutiesVet);
        Veterinarian vet2 = new Veterinarian("Louisa", 28, dutiesVet);
        Veterinarian vet3 = new Veterinarian("Tom", 30, dutiesVet);
        
        //ZooKeepers
        ZooKeeper zooK1 = new ZooKeeper("Jhon", 32, dutiesZk);
        ZooKeeper zooK2 = new ZooKeeper("Thomas", 25, dutiesZk);
*/
        
        //Animals in the Zoo
        ArrayList <Animal> animals = new ArrayList<>();
        animals.add(new Lion("Mufasa",8,"brown"));
        animals.add(new Lion("Taka", 9, "black"));
        animals.add(new Lion("Kiros", 10, "white"));
        animals.add(new Elephant("Dumbo", 3, 200));
        animals.add(new Elephant("Manny", 5, 400));
        animals.add(new Parrot("Blue", 4, "Blue"));
        animals.add(new Parrot("Perla", 3, "Sky blue"));
        
        //Trabajadores del zoo
        ArrayList <Person> trabajadores = new ArrayList<>(); 
        trabajadores.add(new Veterinarian ("Mark", 35, dutiesVet ) ); 
        trabajadores.add(new Veterinarian ("Alejandra", 21, dutiesVet ) );
        trabajadores.add(new ZooKeeper ("Samuel", 30, dutiesZk ) );
        trabajadores.add(new ZooKeeper ("Samanta", 40, dutiesZk ) );
        trabajadores.add(new VentadeBoletas ("Jaunes", 25, dutiesVed ) );
        trabajadores.add(new VentadeBoletas ("Sofia", 20, dutiesVed ) );
        
        
        //Assigning Animals to each veterinarian and zookeeper
        for(Animal a: animals){
            switch (a.getSpecie()) {
                case "Lion":
                    vet1.addAnimal(a);
                    zooK1.addAnimal(a);
                    break;
                case "Elephant":
                    vet2.addAnimal(a);
                    zooK1.addAnimal(a);
                    break;
                case "Parrot":
                    vet3.addAnimal(a);
                    zooK2.addAnimal(a);
                    break;
                default:
                    break;
            }
        }
        
        //Printing the information of the ZOO
        System.out.println("\nZOO INFORMATION SYSTEM");
        System.out.println("--------------------------------------------");
        System.out.println("AVAILABLE VETERINARIANS");
        System.out.println("--------------------------------------------");
        System.out.println(vet1.toString());
        System.out.println(vet2.toString());
        System.out.println(vet3.toString());
        
        System.out.println("--------------------------------------------");
        System.out.println("AVAILABLE ZOOKEEPERS");
        System.out.println("--------------------------------------------");
        System.out.println(zooK1.toString());
        System.out.println(zooK2.toString());
        
        System.out.println("\n---------------------------------------------");
        System.out.println("ANIMALS IN THE ZOO");
        System.out.println("---------------------------------------------");
        for(Animal a: animals){
            System.out.println(a.toString());
        }
    } 
}

