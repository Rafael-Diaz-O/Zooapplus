
package Staff;
import Animals.*;
import java.util.ArrayList;

public class Veterinarian extends Person {
    private ArrayList<Animal> animalsToCare= new ArrayList<>();
    
    public Veterinarian(){
       this.animalsToCare = new ArrayList<>();
    }
    public Veterinarian(String name, int age, ArrayList<String> duties){
       super(name, age, duties);
       this.animalsToCare = new ArrayList<>();
    }
    public void addAnimal(Animal animal){
        this.animalsToCare.add(animal);
    }
    public String getAnimalsInCharge(){
        String str = "";
        for(int i=0; i<this.animalsToCare.size(); i++){
            str += "\n\tSpecie:\t" + this.animalsToCare.get(i).getSpecie() +
                    "\tName:\t" + this.animalsToCare.get(i).getName() + 
                    "\tAge:\t" + this.animalsToCare.get(i).getAge();
        }
        return str;
    }
    @Override
    public String getJobDescription(){
        this.jobDescription = "\nAnimal health and medical treatment";
        return this.jobDescription;
    }
    public String toString(){
        String str;
        str = "\n" + super.toString() + "\n\tAnimals in charge:" + this.getAnimalsInCharge();
        return str;
    }
}
