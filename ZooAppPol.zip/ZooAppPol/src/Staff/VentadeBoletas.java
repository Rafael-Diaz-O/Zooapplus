
package Staff;
import java.util.ArrayList;

public class VentadeBoletas extends Person {
    
   
    public VentadeBoletas (String name, int age, ArrayList<String> duties){
        super(name,age,duties);
        
    }
                
                
        
    
    
    
    
    
    
    
    
    
    
    @Override

    public String getVestimenta(){
        this.vestimenta = "\n Traje de color rojo";
        return this.vestimenta; 
    }
    public String getJobDescription(){
        this.jobDescription = "\nAnimal health and medical treatment";
        return this.jobDescription;
    }
    
    public String toString(){
        String str;
        str = "\n" + super.toString() + "\n\tAnimals in charge:" + this.getAnimalsInCharge()+ this.getVestimenta();
        return str;
    }

}