
package Staff;

public class VentadeBoletas extends Person {
    
    public VentadeBoletas(String name, int age ){
        
        super(name,age); 
        
                
                
        
    }
    
    
    
    
    
    
    
    
    
    
    @Override
    public String getJobDescription(){
        this.jobDescription = "\nAnimal health and medical treatment";
        return this.jobDescription;
    }
    
    public String toString(){
        String str;
        str = "\n" + super.toString() + "\n\tAnimals in charge:" + this.getAnimalsInCharge();
        return str;
    }
}
