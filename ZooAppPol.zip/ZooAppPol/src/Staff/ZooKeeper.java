
package Staff;
import java.util.ArrayList;
import Animals.*;

public class ZooKeeper extends Person{
    
    private ArrayList<Animal> animalsToFeed;
   
    public ZooKeeper(){
        this.animalsToFeed = new ArrayList<>();
    }
    public ZooKeeper(String name, int age, ArrayList<String> duties){
        super(name,age,duties);
        this.animalsToFeed = new ArrayList<>();
    }
    public void addAnimal(Animal animal){
        this.animalsToFeed.add(animal);
    }
    public String getAnimalsInCharge(){
        String str = "";
        for(int i=0; i<this.animalsToFeed.size(); i++){
            str += "\n\tSpecie:\t" + this.animalsToFeed.get(i).getSpecie() +
                    "\tName:\t" + this.animalsToFeed.get(i).getName() + 
                    "\tAge:\t" + this.animalsToFeed.get(i).getAge();
        }
        return str;
    }
    @Override
    public String getJobDescription(){
        this.jobDescription = "\nAnimal care and enclosure maintenance";
        return this.jobDescription;
    }
    public String toString(){
        String str;
        str = "\n" + super.toString() + "\n\tAnimals in charge:" + this.getAnimalsInCharge();
        return str;
    }
    
}
