
package Staff;
import java.util.ArrayList;

public abstract class Person {
    private String name;
    private int age;
    protected String jobDescription;
    protected ArrayList<String> duties;
    protected String vestimenta;
    
    public Person(){
        this.name = null;
        this.age = 0;
        this.jobDescription = null;
        this.vestimenta = null; 
        this.duties= new ArrayList<>();
    }
    public Person(String name, int age,  ArrayList<String>duties){
        this.name = name;
        this.age = age;
        this.jobDescription = null;
        this.vestimenta = null; 
        this.duties = duties;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getName() {
        return this.name;
    }
    public int getAge() {
        return this.age;
    }
    public void setDuties(ArrayList<String> duties){
        this.duties = duties;    
    }
    public String getDuties(){
        String str = "";
        for(int i=0; i<this.duties.size(); i++){
            str += this.duties.get(i) + "\n";
        }
        return str;
    }
    @Override
    public String toString() {
        String str = "Name:" + this.name + "\nAge: " + this.age;
        return str;
    }    
    
    public abstract String getJobDescription();
    public abstract String getVestimenta(); 
    
}