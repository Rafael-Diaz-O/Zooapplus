
package Animals;
import Staff.*;

public class Elephant extends Animal{
    public double size;
    
    public Elephant(){
    }
    public Elephant(String name, int age, double size){
        super(name,age);
        this.size = size;
    }
    public void setSize(double size){
        this.size = size;
    }
    public double getSize(){
        return this.size;
    }
    @Override
    public String makeSound() {
        String str = "\n" + this.getName()+ " trumpets with its trunk!";
        return str;
    }
    @Override
    public String eat() {
        String str = "\n" + this.getName() + " is eating leaves and fruits";
        return str;
    }
    public String getSpecie(){
        return "Elephant";
    }
    @Override
    public String toString(){
        String str = super.toString() + "\nSpecie:\t\t" + this.getSpecie() + "\nSize:\t\t" + this.getSize()+
                this.makeSound() + this.eat();
        return str;
    }
}
