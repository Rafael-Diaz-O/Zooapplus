
package Animals;
import Staff.*;

public class Lion extends Animal{
    private String maneColor;
    
    public Lion(){
    }
    public Lion(String name, int age, String maneColor){
        super(name, age);
        this.maneColor = maneColor;
    }
    public void setManeColor(String maneColor){
        this.maneColor = maneColor;
    }
    public String getManeColor(){
        return this.maneColor;
    }
    @Override
    public String makeSound() {
        String str = "\n" + this.getName() + " roars loudly!";
        return str;
    }
    @Override
    public String eat() {
        String str = "\n" + this.getName() + " is eating a big piece of meat";
        return str;
    }
    @Override
    public String getSpecie(){
        return "Lion";
    }
    @Override
    public String toString(){
        String str = super.toString() + "\nSpecie:\t\t" + this.getSpecie() + "\nMane color:\t" + this.getManeColor()
                + this.makeSound() + this.eat();
        return str;
    }
}