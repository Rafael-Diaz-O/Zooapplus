
package Animals;
import Staff.*;

public abstract class Animal {
    private String name;
    private int age;
    
    public Animal(){
    }
    public Animal(String name, int age){
        this.name = name;
        this.age = age;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setAge(int age){
        this.age = age;
    }
    public String getName(){
        return this.name;
    }
    public int getAge(){
        return this.age;
    }
    public abstract String makeSound();
    public abstract String eat(); 
    public abstract String getSpecie();
    
    public String toString(){
        String str = "\nName:\t\t" + this.getName()+
                "\nAge:\t\t" + this.getAge();
        return str;
    }
}
