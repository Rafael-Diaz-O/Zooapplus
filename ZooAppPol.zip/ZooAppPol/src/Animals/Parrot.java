
package Animals;
import Staff.*;

public class Parrot extends Animal{
    private String featherColor;
    
    public Parrot(){
    }
    public Parrot(String name, int age, String featherColor){
        super(name, age);
        this.featherColor = featherColor;
    }
    public void setFeatherColor(String color){
        this.featherColor = color;
    }
    public String getFeatherColor(){
        return this.featherColor;
    }
    @Override
    public String makeSound() {
        String str = "\n" + this.getName()+ " says: Hello! Pretty bird!";
        return str;
    }
    @Override
    public String eat() {
        String str = "\n" + this.getName() + " is eating seeds and nuts";
        return str;
    }
    @Override
    public String getSpecie(){
        return "Parrot";
    }
    @Override
    public String toString(){
        String str = super.toString() + "\nSpecie:\t\t" + this.getSpecie() + 
                "\nFeather color:\t" + this.getFeatherColor()+
                this.makeSound() + this.eat();
        return str;
    }
}